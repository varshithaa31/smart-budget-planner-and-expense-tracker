from django.contrib import admin
from .models import CustomUser, Feedback, UserDNAProfile, Transaction, Budget, Goal

@admin.register(Feedback)
class FeedbackAdmin(admin.ModelAdmin):
    list_display = ('user', 'rating', 'comment', 'created_at')
    list_filter = ('rating', 'created_at')
    search_fields = ('user__username', 'comment')
    ordering = ('-created_at',)

@admin.register(CustomUser)
class CustomUserAdmin(admin.ModelAdmin):
    list_display = ('username', 'email', 'is_staff', 'is_active')
    search_fields = ('username', 'email')

@admin.register(UserDNAProfile)
class UserDNAProfileAdmin(admin.ModelAdmin):
    list_display = ('user', 'personality_tag', 'is_onboarded')

admin.site.register(Transaction)
admin.site.register(Budget)
admin.site.register(Goal)
