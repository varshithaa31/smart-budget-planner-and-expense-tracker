from rest_framework import generics
from rest_framework.permissions import AllowAny
from django.contrib.auth import get_user_model
from .serializers import CustomUserSerializer

User = get_user_model()

class RegisterView(generics.CreateAPIView):
    queryset = User.objects.all()
    permission_classes = (AllowAny,)
    serializer_class = CustomUserSerializer

from rest_framework.views import APIView
from rest_framework.response import Response
from rest_framework.permissions import IsAuthenticated, IsAdminUser
from django.db.models import Count, Q
from datetime import timedelta
from .serializers import UserDNAProfileSerializer
from .models import UserDNAProfile
from .services import determine_financial_personality

class OnboardingDNAView(APIView):
    permission_classes = [IsAuthenticated]

    def post(self, request):
        serializer = UserDNAProfileSerializer(data=request.data)
        if serializer.is_valid():
            income = serializer.validated_data.get('income_fixed', 0) + serializer.validated_data.get('income_variable', 0)
            category = serializer.validated_data.get('user_category')
            goals = serializer.validated_data.get('financial_goals')
            
            tag = determine_financial_personality(income, category, goals)
            
            profile, created = UserDNAProfile.objects.update_or_create(
                user=request.user,
                defaults={
                    'income_fixed': serializer.validated_data.get('income_fixed', 0),
                    'income_variable': serializer.validated_data.get('income_variable', 0),
                    'user_category': category,
                    'financial_goals': goals,
                    'personality_tag': tag,
                    'is_onboarded': True
                }
            )
            
            from .services import auto_allocate_budget
            auto_allocate_budget(request.user, profile.income_fixed, profile.income_variable, tag)
            
            return Response({
                'status': 'success', 
                'personality_tag': tag,
                'is_new_profile': created
            })
        return Response(serializer.errors, status=400)


class LoginCheckView(APIView):
    """Check if current user is onboarded — used to decide redirect target after login."""
    permission_classes = [IsAuthenticated]

    def get(self, request):
        profile = getattr(request.user, 'dna_profile', None)
        return Response({
            'is_onboarded': profile.is_onboarded if profile else False,
            'username': request.user.username
        })


class UserProfileView(APIView):
    """GET all profile data, PUT to update (triggers budget re-allocation if salary changes)."""
    permission_classes = [IsAuthenticated]

    def get(self, request):
        user = request.user
        profile = getattr(user, 'dna_profile', None)
        if not profile:
            return Response({'error': 'No profile found. Complete onboarding first.'}, status=404)
        
        return Response({
            'username': user.username,
            'email': user.email,
            'income_fixed': str(profile.income_fixed),
            'income_variable': str(profile.income_variable),
            'user_category': profile.user_category,
            'personality_tag': profile.personality_tag,
            'financial_goals': profile.financial_goals,
            'is_onboarded': profile.is_onboarded,
            'preferred_currency': profile.preferred_currency,
        })

    def put(self, request):
        user = request.user
        profile = getattr(user, 'dna_profile', None)
        if not profile:
            return Response({'error': 'No profile found.'}, status=404)
        
        old_salary = float(profile.income_fixed) + float(profile.income_variable)
        
        # Update user fields
        if 'email' in request.data:
            user.email = request.data['email']
            user.save()
        
        # Update profile fields
        if 'income_fixed' in request.data:
            profile.income_fixed = request.data['income_fixed']
        if 'income_variable' in request.data:
            profile.income_variable = request.data['income_variable']
        if 'user_category' in request.data:
            profile.user_category = request.data['user_category']
        if 'financial_goals' in request.data:
            profile.financial_goals = request.data['financial_goals']
        if 'preferred_currency' in request.data:
            profile.preferred_currency = request.data['preferred_currency']
        
        if 'profile_photo' in request.FILES:
            profile.profile_photo = request.FILES['profile_photo']
            
        profile.save()
        
        new_salary = float(profile.income_fixed) + float(profile.income_variable)
        
        # Re-allocate budgets if salary changed
        budget_reallocated = False
        if abs(new_salary - old_salary) > 0.01:
            from .services import auto_allocate_budget
            auto_allocate_budget(user, profile.income_fixed, profile.income_variable, profile.personality_tag or 'Balanced')
            budget_reallocated = True
        
        res_data = {
            'status': 'success',
            'budget_reallocated': budget_reallocated
        }
        if profile.profile_photo:
            res_data['profile_photo_url'] = profile.profile_photo.url
            
        return Response(res_data)

from .models import Transaction, Budget, Feedback
from django.utils import timezone
import calendar
import pytz

def format_localized_date(dt_obj, currency):
    tz_map = {
        'INR': 'Asia/Kolkata',
        'USD': 'America/New_York',
        'EUR': 'Europe/Paris'
    }
    tz_name = tz_map.get(currency, 'UTC')
    try:
        local_tz = pytz.timezone(tz_name)
        local_dt = dt_obj.astimezone(local_tz)
        return local_dt.strftime('%b %d, %Y | %I:%M %p')
    except:
        return dt_obj.strftime('%b %d, %Y | %I:%M %p')

class DashboardDataView(APIView):
    permission_classes = [IsAuthenticated]

    def get(self, request):
        user = request.user
        profile = getattr(user, 'dna_profile', None)
        
        now = timezone.now()
        _, last_day = calendar.monthrange(now.year, now.month)
        days_in_month = last_day
        days_passed = now.day
        days_left = days_in_month - days_passed
        
        transactions = Transaction.objects.filter(user=user, date__year=now.year, date__month=now.month)
        total_spent = sum([float(t.amount) for t in transactions])
        total_salary = float(profile.income_fixed + profile.income_variable) if profile else 0.0
        remaining_balance = total_salary - total_spent
        
        burn_rate_daily = float(total_spent) / days_passed if days_passed > 0 else 0
        burn_rate_monthly = burn_rate_daily * days_in_month
        
        days_until_exhaustion = remaining_balance / burn_rate_daily if burn_rate_daily > 0 else 'Infinite'
        if isinstance(days_until_exhaustion, float) and days_until_exhaustion < 0:
            days_until_exhaustion = 0
            
        # Ensure "Others" is always last in budget list
        budgets = list(Budget.objects.filter(user=user))
        budgets.sort(key=lambda b: (b.category_name == 'Others', b.category_name))
        budget_data = [{'category': b.category_name, 'allocated': float(b.allocated_amount or 0), 'percentage': float(b.allocated_percentage)} for b in budgets]
        
        category_spending = {}
        for t in transactions:
            category_spending[t.category] = category_spending.get(t.category, 0) + float(t.amount)
        
        # Sort category_spending so "Others" is last
        sorted_spending = {}
        for k in sorted(category_spending.keys(), key=lambda x: (x == 'Others', x)):
            sorted_spending[k] = category_spending[k]
            
        return Response({
            'total_spent': round(total_spent, 2),
            'total_salary': round(total_salary, 2),
            'remaining_balance': round(remaining_balance, 2),
            'burn_rate_daily': round(burn_rate_daily, 2),
            'burn_rate_monthly_projected': round(burn_rate_monthly, 2),
            'days_until_exhaustion': round(days_until_exhaustion, 0) if isinstance(days_until_exhaustion, float) else days_until_exhaustion,
            'budgets': budget_data,
            'category_spending': sorted_spending,
            'dna_tag': profile.personality_tag if profile else 'Unknown',
            'preferred_currency': profile.preferred_currency if profile else 'USD',
            'financial_goals': profile.financial_goals if profile else 'goals',
            'behavior_analytics': {
                'pattern_detection': {
                    'weekend_overspend': any(t.date.weekday() >= 5 for t in transactions),
                    'night_spend': any(getattr(t, 'is_night_spending', False) for t in transactions),
                    'category_spike': max(sorted_spending, key=sorted_spending.get) if sorted_spending else 'None'
                },
                'advanced_detection': {
                    'impulse_count': len([t for t in transactions if t.category in ['Shopping', 'Entertainment'] and t.amount > 20]),
                    'subscription_leaks': len([t for t in transactions if getattr(t, 'is_subscription_leak', False)])
                },
                'forecast': {
                    'expected_monthend_spend': burn_rate_daily * days_in_month,
                    'expected_savings': total_salary - (burn_rate_daily * days_in_month),
                    'budget_balance': total_salary - total_spent
                }
            }
        })

from .services import extract_expense_info

class QuickAddTransactionView(APIView):
    permission_classes = [IsAuthenticated]

    def post(self, request):
        text = request.data.get('text', '')
        if not text:
            return Response({'error': 'No text provided'}, status=400)
            
        extraction = extract_expense_info(request.user, text)
        
        now = timezone.now()
        is_night = now.hour >= 22 or now.hour <= 4
        
        transaction = Transaction.objects.create(
            user=request.user,
            amount=extraction['amount'],
            category=extraction['category'],
            sub_category=extraction['sub_category'],
            description=text,
            is_night_spending=is_night,
            is_subscription_leak=extraction.get('is_subscription_leak', False)
        )
        
        return Response({
            'status': 'success',
            'transaction_id': transaction.id,
            'amount': transaction.amount,
            'category': transaction.category
        })

class ManualAddTransactionView(APIView):
    permission_classes = [IsAuthenticated]

    def post(self, request):
        amount = request.data.get('amount')
        category = request.data.get('category')
        description = request.data.get('description', 'Manual entry')

        if not amount or not category:
            return Response({'error': 'Amount and category are required'}, status=400)

        now = timezone.now()
        is_night = now.hour >= 22 or now.hour <= 4
        
        transaction = Transaction.objects.create(
            user=request.user,
            amount=amount,
            category=category,
            sub_category='User-Entered',
            description=description,
            is_night_spending=is_night
        )

        return Response({
            'status': 'success',
            'transaction_id': transaction.id,
            'amount': transaction.amount,
            'category': transaction.category
        })

class TransactionCorrectionView(APIView):
    permission_classes = [IsAuthenticated]

    def post(self, request, transaction_id):
        new_category = request.data.get('category')
        try:
            transaction = Transaction.objects.get(id=transaction_id, user=request.user)
            transaction.category = new_category
            transaction.sub_category = "User-Corrected"
            transaction.save()
            
            return Response({'status': 'success', 'message': 'Learning loop updated.'})
        except Transaction.DoesNotExist:
            return Response({'error': 'Not found'}, status=404)

class ChatbotView(APIView):
    permission_classes = [AllowAny]

    def post(self, request):
        query = request.data.get('query', '').lower()
        if not query:
            return Response({'error': 'No query provided'}, status=400)

        # Guest Mode Check
        if not request.user.is_authenticated:
            # FAQ Keywords
            faq_keywords = ['how', 'what', 'why', 'who', 'work', 'feature', 'help', 'security', 'secure']
            is_faq = any(kw in query for kw in faq_keywords)
            
            if "feedback" in query or "rate" in query or "😍" in query or "☹️" in query:
                return Response({'reply': "Please Log In to share your experience with us."})
            
            if not is_faq:
                return Response({'reply': "I'm restricted to basic FAQs for guests. Please Log In to access my full suite of financial insights and logging capabilities!"})
            
            # Simple FAQ responses for guests
            if "security" in query or "secure" in query:
                return Response({'reply': "WiseWallet uses AES-256 encryption and multi-factor authentication to ensure your financial data is safe and private."})
            if "work" in query or "how" in query:
                return Response({'reply': "I am Calex 🤖. I help track expenses, analyze spending habits, and provide AI-driven financial advice. Please log in to see me in action!"})
            
            return Response({'reply': "I can help with general questions! For personalized financial tracking, please sign in."})

        # Member Mode (Auth required beyond this point)
        user = request.user
        if not query:
            return Response({'reply': 'I am Calex, your WiseWallet AI. How can I help you?'})

        is_auth = request.user.is_authenticated
        
        # Define restricted intents
        expense_keywords = ['$', '₹', '€', 'spent', 'bought', 'paid', 'add', 'log', 'save']
        personal_keywords = ['my', 'me', 'i ', 'mine', 'balance', 'salary', 'income', 'budget', 'history', 'habit', 'prediction']
        
        is_expense_intent = any(w in query for w in expense_keywords) and any(char.isdigit() for char in query)
        is_personal_intent = any(w in query for w in personal_keywords)
        
        if not is_auth:
            # FAQ Mode for Guests
            faq_responses = {
                'how does wisewallet work': "WiseWallet is an AI-powered financial assistant that helps you track expenses, automate budgets, and get personalized savings advice. You can log expenses via text or voice, and we'll categorize them automatically!",
                'what is wisewallet': "WiseWallet is your personal finance companion. It uses AI to analyze your spending habits and helps you stay on track with your financial goals using the 50/30/20 rule or custom budgets.",
                'features': "WiseWallet features include: \n• AI Chatbot (Calex) for quick logging\n• Voice-to-Expense commands\n• Dynamic Budget Generation\n• Spending Analytics & Habit Detection\n• 3-Month Financial Predictions",
                'who is calex': "I am Calex! 🤖 Your AI financial guide. I help you manage your money, log daily spends, and provide smart insights to improve your financial health.",
            }
            
            # Check for FAQ match
            for faq_q, faq_r in faq_responses.items():
                if faq_q in query:
                    return Response({'reply': faq_r})
            
            # Handle restricted requests for Guests
            if is_expense_intent or is_personal_intent or any(w in query for w in ['how am i', 'my progress', 'show']):
                return Response({'reply': "Request cannot be processed. Please Log In to access full financial operations."})
            
            # Default guide for Guests
            return Response({'reply': "I can answer general questions about WiseWallet (e.g., 'How does WiseWallet work?'). To log expenses or see your personal analytics, please log in!"})

        # Authenticated Mode Logic
        now = timezone.now()
        transactions = Transaction.objects.filter(user=request.user, date__year=now.year, date__month=now.month)
        profile = getattr(request.user, 'dna_profile', None)
        total_income = float(profile.income_fixed + profile.income_variable) if profile else 0.0
        total_spent = sum([float(t.amount) for t in transactions])
        
        # 0. Navigation intents
        nav_routes = {
            'home': '/dashboard/', 'dashboard': '/dashboard/',
            'report': '/dashboard/', 'reports': '/dashboard/',
            'profile': '/profile/', 'habit': '/habits/', 'habits': '/habits/',
            'prediction': '/predictions/', 'predictions': '/predictions/',
            'budget': '/dashboard/', 'history': '/dashboard/'
        }
        nav_keywords = ['go to', 'take me to', 'open', 'navigate to', 'show me', 'show']
        for kw in nav_keywords:
            if kw in query:
                after = query.split(kw, 1)[1].strip().rstrip('.')
                for nav_name, nav_url in nav_routes.items():
                    if nav_name in after:
                        tab_map = {'report': 'reports', 'reports': 'reports', 'budget': 'budget', 'history': 'history', 'profile': 'profile'}
                        tab = tab_map.get(nav_name, '')
                        url = nav_url + (f'?tab={tab}' if tab and nav_url == '/dashboard/' else '')
                        return Response({
                            'reply': f"Taking you to {nav_name.title()} now! 🚀",
                            'redirect_to': url
                        })

        # 1. Check for Expense Addition
        from .services import CATEGORY_KEYWORDS, extract_expense_info
        all_cat_keywords = [kw for kws in CATEGORY_KEYWORDS.values() for kw in kws]
        is_expense_addition = any(w in query for w in expense_keywords) or any(w in query for w in all_cat_keywords)

        if is_expense_addition and any(char.isdigit() for char in query):
            extraction = extract_expense_info(request.user, query)
            if extraction and extraction['amount'] > 0:
                is_night = now.hour >= 22 or now.hour <= 4
                Transaction.objects.create(
                    user=request.user,
                    amount=extraction['amount'],
                    category=extraction['category'],
                    sub_category=extraction['sub_category'],
                    description=query,
                    is_night_spending=is_night,
                    is_subscription_leak=extraction.get('is_subscription_leak', False)
                )
                remaining = total_income - total_spent - extraction['amount']
                appreciation = ""
                if remaining > total_income * 0.5:
                    appreciation = " 🎉 Great job — you still have over half your budget remaining!"
                elif remaining > total_income * 0.2:
                    appreciation = " 👍 Good work staying within budget this month!"
                return Response({
                    'reply': f"Got it! I've logged {extraction['amount']:.2f} under {extraction['category']}.{appreciation}",
                    'reload_dashboard': True
                })

        # 2. Savings Appreciation & Goal Advice
        if any(w in query for w in ['appreciate', 'how am i doing', 'progress', 'advice', 'goal']):
            savings = total_income - total_spent
            goal_text = f" for your goal: '{profile.financial_goals}'" if profile and profile.financial_goals else ""
            if savings > total_income * 0.5:
                reply = f"🌟 Amazing! You've saved {savings:.2f} this month — over 50% of your salary. This is excellent progress{goal_text}!"
            elif savings > total_income * 0.2:
                reply = f"👍 Great job staying under budget! You have {savings:.2f} left this month, keeping you on track{goal_text}."
            elif savings > 0:
                reply = f"⚠️ You've spent most of your budget. Only {savings:.2f} remains. To reach your goal faster, try to cut back on discretionary spending."
            else:
                reply = f"🚨 You've overspent by {abs(savings):.2f} this month. I recommend reviewing your 'Spending Habits' tab to identify where to cut back."
            return Response({'reply': reply})

        # 3. Feature questions
        if any(w in query for w in ['how do i edit', 'edit budget', 'edit my budget', 'change budget', 'modify budget']):
            reply = ("To edit your budget:\n"
                     "1. Go to the ⚙️ Budget Generator tab in the sidebar\n"
                     "2. Edit the amount for any category and click 'Save'\n"
                     "3. To add a new category, scroll to 'Add Custom Category'\n"
                     "4. To delete a category, click 'Del' next to it\n"
                     "💡 Tip: Changing your salary in Profile auto-recalculates all budgets!")
            return Response({'reply': reply})

        if any(w in query for w in ['why', 'overspend', 'too much', 'spending too']):
            cat_totals = {}
            for t in transactions:
                cat_totals[t.category] = cat_totals.get(t.category, 0) + float(t.amount)
            if cat_totals:
                top_cat = max(cat_totals, key=cat_totals.get)
                top_amt = cat_totals[top_cat]
                reply = f"🔍 Your highest spending is in {top_cat} at {top_amt:.2f}. "
                if top_cat == 'Food':
                    reply += "Try meal-prepping or reducing restaurant visits to save more."
                elif top_cat == 'Shopping':
                    reply += "Consider a 48-hour rule — wait before impulse purchases."
                elif top_cat == 'Entertainment':
                    reply += "Check for unused subscriptions — they add up quickly!"
                else:
                    reply += f"Review your {top_cat} expenses for potential savings opportunities."
            else:
                reply = "No spending data yet this month. Start logging expenses to get insights!"
            return Response({'reply': reply})

        if any(w in query for w in ['work', 'how to use', 'what is this', 'feature', 'help', 'what can you do']):
            reply = ("I am Calex, your WiseWallet AI 🤖. Here's what I can do for you:\n"
                     "• **Log Expenses**: Type 'Spent 500 on food' or use the 🎤 button\n"
                     "• **Check Progress**: Ask 'How am I doing?' for savings advice\n"
                     "• **Analyze Habits**: Ask 'Why am I overspending?'\n"
                     "• **Navigate**: Say 'Go to Profile' or 'Show Predictions'\n"
                     "• **Budget Help**: Ask 'How do I edit my budget?'\n"
                     "• **Feedback**: Share your experience via our <a href='#' onclick='openFeedbackFromPrompt(); return false;' class='text-decoration-underline fw-bold' style='color: var(--accent);'>Feedback Form</a>\n"
                     "• **Reports**: View analytics in the Reports tab")
            return Response({'reply': reply})

        if any(w in query for w in ['feedback', 'rate', 'testimonial', 'experience']):
            return Response({
                'reply': "I'd love to hear your thoughts! Your feedback helps me become a better financial assistant. 💜<br><br><button class='btn btn-sm btn-light rounded-pill fw-bold mt-2' onclick='openFeedbackFromPrompt()'>Give Feedback 😍</button>"
            })
        
        # 4. Category-specific spending queries
        from .services import BUDGET_CATEGORIES
        for cat in BUDGET_CATEGORIES:
            if cat.lower() in query:
                cat_spent = sum([float(t.amount) for t in transactions if t.category == cat])
                budgets = Budget.objects.filter(user=request.user, category_name=cat)
                allocated = float(budgets.first().allocated_amount) if budgets.exists() else 0
                remaining = allocated - cat_spent
                reply = f"You've spent {cat_spent:.2f} on {cat} this month."
                if allocated > 0:
                    reply += f" Your budget for {cat} is {allocated:.2f}, leaving {remaining:.2f}."
                    if remaining < 0:
                        reply += " ⚠️ You've exceeded this budget!"
                    elif remaining < allocated * 0.2:
                        reply += " 🔶 Getting close to the limit."
                return Response({'reply': reply})

        # 5. General spending queries
        if 'save' in query or 'savings' in query:
            savings = total_income - total_spent
            reply = f"Based on your salary of {total_income:.2f} and spending of {total_spent:.2f}, your current savings stand at {savings:.2f} this month."
        elif 'spend' in query or 'spent' in query or 'total' in query:
            reply = f"Your total spending this month is {total_spent:.2f}."
        elif 'budget' in query:
            budgets = Budget.objects.filter(user=request.user)
            if budgets.exists():
                budget_summary = ", ".join([f"{b.category_name}: {b.allocated_amount}" for b in budgets[:5]])
                reply = f"Your top budgets: {budget_summary}. Visit the Budget Generator tab for full details."
            else:
                reply = "No budgets configured yet. Complete onboarding to get AI-generated budgets."
        elif 'salary' in query or 'income' in query:
            reply = f"Your total monthly salary is {total_income:.2f} (Fixed: {float(profile.income_fixed):.2f}, Variable: {float(profile.income_variable):.2f})." if profile else "No profile found. Complete onboarding first."
        else:
            reply = "I am Calex, your financial AI 🤖. You can tell me to log an expense (e.g., 'Spent 500 on food'), ask about your savings, spending, or budget, or say 'help' to see all features!"
            
        return Response({'reply': reply})

class BudgetListView(APIView):
    permission_classes = [IsAuthenticated]

    def get(self, request):
        from django.utils import timezone
        now = timezone.now()
        transactions = Transaction.objects.filter(user=request.user, date__year=now.year, date__month=now.month)
        
        # Sort: Others always last
        budgets = list(Budget.objects.filter(user=request.user))
        budgets.sort(key=lambda b: (b.category_name == 'Others', b.category_name))
        
        data = []
        for b in budgets:
            spent = sum([t.amount for t in transactions if t.category == b.category_name])
            data.append({
                'id': b.id,
                'category_name': b.category_name,
                'allocated_percentage': str(b.allocated_percentage),
                'allocated_amount': str(b.allocated_amount) if b.allocated_amount else '0',
                'spent_amount': str(spent)
            })
        return Response({'budgets': data})

    def post(self, request):
        category_name = request.data.get('category_name')
        allocated_amount = request.data.get('allocated_amount', 0)
        
        if not category_name:
            return Response({'error': 'Name required'}, status=400)
            
        b = Budget.objects.create(
            user=request.user,
            category_name=category_name,
            allocated_amount=allocated_amount,
            allocated_percentage=0 # Custom categories can skip forcing percentages
        )
        return Response({'id': b.id, 'status': 'success'})

class BudgetDetailView(APIView):
    permission_classes = [IsAuthenticated]

    def put(self, request, pk):
        try:
            budget = Budget.objects.get(pk=pk, user=request.user)
            budget.allocated_amount = request.data.get('allocated_amount', budget.allocated_amount)
            budget.category_name = request.data.get('category_name', budget.category_name)
            budget.save()
            return Response({'status': 'updated'})
        except Budget.DoesNotExist:
            return Response({'error': 'Not found'}, status=404)

    def delete(self, request, pk):
        try:
            Budget.objects.get(pk=pk, user=request.user).delete()
            return Response({'status': 'deleted'})
        except Budget.DoesNotExist:
            return Response({'error': 'Not found'}, status=404)

class TransactionHistoryView(APIView):
    permission_classes = [IsAuthenticated]
    
    def get(self, request):
        profile = getattr(request.user, 'dna_profile', None)
        currency = profile.preferred_currency if profile else 'USD'
        txs = Transaction.objects.filter(user=request.user).order_by('-date')[:50]
        data = [{
            'id': t.id,
            'amount': str(t.amount),
            'category': t.category,
            'date': format_localized_date(t.date, currency),
            'description': t.description,
            'sub_category': t.sub_category
        } for t in txs]
        return Response({'transactions': data})

class TransactionDetailView(APIView):
    permission_classes = [IsAuthenticated]
    
    def delete(self, request, pk):
        try:
            transaction = Transaction.objects.get(pk=pk, user=request.user)
            transaction.delete()
            return Response({'status': 'success', 'message': 'Transaction deleted successfully.'})
        except Transaction.DoesNotExist:
            return Response({'error': 'Transaction not found.'}, status=404)


class MonthlyReportView(APIView):
    """Returns a monthly spending summary as JSON."""
    permission_classes = [IsAuthenticated]

    def get(self, request):
        now = timezone.now()
        month_name = now.strftime('%B %Y')
        transactions = Transaction.objects.filter(user=request.user, date__year=now.year, date__month=now.month)
        profile = getattr(request.user, 'dna_profile', None)
        total_income = float(profile.income_fixed + profile.income_variable) if profile else 0.0
        total_spent = sum([float(t.amount) for t in transactions])
        savings = total_income - total_spent
        savings_rate = (savings / total_income * 100) if total_income > 0 else 0

        budgets = Budget.objects.filter(user=request.user)
        budget_map = {b.category_name: float(b.allocated_amount) for b in budgets}

        # Category breakdown
        category_breakdown = {b.category_name: 0.0 for b in budgets}
        for t in transactions:
            category_breakdown[t.category] = category_breakdown.get(t.category, 0) + float(t.amount)

        # Sort: Others last
        sorted_breakdown = []
        for k in sorted(category_breakdown.keys(), key=lambda x: (x == 'Others', x)):
            sorted_breakdown.append({
                'category': k, 
                'spent': round(category_breakdown[k], 2),
                'allocated': round(budget_map.get(k, 0.0), 2)
            })

        top_category = max(category_breakdown, key=category_breakdown.get) if category_breakdown else 'None'

        return Response({
            'month': month_name,
            'total_income': round(total_income, 2),
            'total_spent': round(total_spent, 2),
            'savings': round(savings, 2),
            'savings_rate': round(savings_rate, 1),
            'top_category': top_category,
            'category_breakdown': sorted_breakdown,
            'transaction_count': len(transactions),
            'dna_tag': profile.personality_tag if profile else 'Unknown'
        })


class DownloadReportPDFView(APIView):
    """Generates a PDF monthly financial report and returns it for download."""
    permission_classes = [IsAuthenticated]

    def get(self, request):
        from io import BytesIO
        from xhtml2pdf import pisa
        from django.http import HttpResponse
        from django.template.loader import render_to_string

        now = timezone.now()
        month_name = now.strftime('%B %Y')
        transactions = Transaction.objects.filter(user=request.user, date__year=now.year, date__month=now.month)
        profile = getattr(request.user, 'dna_profile', None)
        total_income = float(profile.income_fixed + profile.income_variable) if profile else 0.0
        total_spent = sum([float(t.amount) for t in transactions])
        savings = total_income - total_spent
        savings_rate = (savings / total_income * 100) if total_income > 0 else 0

        budgets = Budget.objects.filter(user=request.user)
        budget_map = {b.category_name: float(b.allocated_amount) for b in budgets}

        # Category breakdown
        cat_data = {b.category_name: 0.0 for b in budgets}
        for t in transactions:
            cat_data[t.category] = cat_data.get(t.category, 0) + float(t.amount)

        # Health score calculation (simple heuristic based on savings and budget limits)
        health_score = 100
        health_message = "Mighty fine financial control this month! Keep saving."
        score_color = "#10b981" # Green
        
        if savings < 0:
            health_score -= 40
            health_message = "You have overspent your total income. Immediate review needed."
            score_color = "#ef4444" # Red
        elif savings_rate < 10:
            health_score -= 20
            health_message = "Your savings rate is a bit low. Try to reach 20%."
            score_color = "#f59e0b" # Yellow

        budget_rows = []
        for k in sorted(cat_data.keys(), key=lambda x: (x == 'Others', x)):
            spent = cat_data[k]
            alloc = budget_map.get(k, 0.0)
            pct = (spent / alloc * 100) if alloc > 0 else (100 if spent > 0 else 0)
            
            if pct > 100:
                health_score = max(0, health_score - 5)
                color_class = "fill-red"
            elif pct > 85:
                color_class = "fill-yellow"
            else:
                color_class = "fill-green"
                
            budget_rows.append({
                'category': k,
                'spent': spent,
                'allocated': alloc,
                'width_pct': min(100, pct),
                'color_class': color_class
            })
            
        health_score = max(0, min(100, int(health_score)))
        if health_score < 60:
            score_color = "#ef4444"
        elif health_score < 80:
            score_color = "#f59e0b"

        top_category = max(cat_data, key=cat_data.get) if cat_data else 'None'
        
        context = {
            'month_name': month_name,
            'username': request.user.username,
            'health_score': health_score,
            'health_message': health_message,
            'score_color': score_color,
            'total_income': total_income,
            'total_spent': total_spent,
            'savings': savings,
            'savings_rate': savings_rate,
            'budget_rows': budget_rows,
            'top_category': top_category,
            'dna_tag': profile.personality_tag if profile else 'Unknown',
            'generation_time': timezone.localtime(now).strftime('%Y-%m-%d %I:%M %p')
        }

        html_content = render_to_string('report_pdf.html', context)
        result = BytesIO()
        pdf = pisa.CreatePDF(html_content, dest=result)
        if pdf.err:
            return Response({'error': 'PDF generation failed'}, status=500)

        response = HttpResponse(result.getvalue(), content_type='application/pdf')
        response['Content-Disposition'] = f'attachment; filename="SmartBudget_Report_{now.strftime("%Y_%m")}.pdf"'
        return response


class HabitsAnalyticsView(APIView):
    """Returns spending frequency data by hour and day-of-week, plus AI goal-driven suggestions."""
    permission_classes = [IsAuthenticated]

    def get(self, request):
        import calendar as cal
        now = timezone.now()
        transactions = Transaction.objects.filter(user=request.user, date__year=now.year, date__month=now.month)
        profile = getattr(request.user, 'dna_profile', None)
        total_income = float(profile.income_fixed + profile.income_variable) if profile else 0.0
        financial_goals = profile.financial_goals if profile else 'your goals'

        # Frequency by hour (0-23)
        hour_freq = [0] * 24
        for t in transactions:
            local_dt = timezone.localtime(t.date)
            hour_freq[local_dt.hour] += 1

        # Frequency by day-of-week (Mon=0 .. Sun=6)
        day_names = ['Mon', 'Tue', 'Wed', 'Thu', 'Fri', 'Sat', 'Sun']
        day_freq = [0] * 7
        for t in transactions:
            local_dt = timezone.localtime(t.date)
            day_freq[local_dt.weekday()] += 1

        # Category totals for this month
        cat_totals = {}
        for t in transactions:
            cat_totals[t.category] = cat_totals.get(t.category, 0) + float(t.amount)

        # Top 3 categories
        sorted_cats = sorted(cat_totals.items(), key=lambda x: x[1], reverse=True)
        top_categories = [{'category': c, 'amount': round(a, 2)} for c, a in sorted_cats[:5]]

        # Weekly spending (last 7 days)
        from datetime import timedelta
        week_ago = now - timedelta(days=7)
        weekly_txs = [t for t in transactions if t.date >= week_ago]
        weekly_cat_totals = {}
        for t in weekly_txs:
            weekly_cat_totals[t.category] = weekly_cat_totals.get(t.category, 0) + float(t.amount)

        # AI Suggestions
        suggestions = []
        total_spent = sum(cat_totals.values())
        if sorted_cats:
            top_cat, top_amt = sorted_cats[0]
            saved_10 = round(top_amt * 0.10, 2)
            # Calculate days sooner to goal
            monthly_savings = total_income - total_spent
            if monthly_savings > 0 and saved_10 > 0:
                days_sooner = round((saved_10 / monthly_savings) * 30, 0)
            else:
                days_sooner = 15
            suggestions.append(
                f"You spent ${top_amt:.2f} on {top_cat} this week. If you reduce this by 10%, "
                f"you will reach your '{financial_goals}' goal {int(days_sooner)} days sooner!"
            )

        # Weekend vs weekday analysis
        weekend_spend = sum(float(t.amount) for t in transactions if timezone.localtime(t.date).weekday() >= 5)
        weekday_spend = total_spent - weekend_spend
        if weekend_spend > weekday_spend * 0.5 and len(transactions) > 3:
            suggestions.append(
                f"⚠️ You spend {((weekend_spend/total_spent)*100):.0f}% of your budget on weekends. "
                f"Try planning free activities on Saturdays to save more for '{financial_goals}'."
            )

        # Night spending analysis
        night_spend = sum(float(t.amount) for t in transactions if timezone.localtime(t.date).hour >= 22 or timezone.localtime(t.date).hour <= 4)
        if night_spend > total_spent * 0.15 and len(transactions) > 3:
            suggestions.append(
                f"🌙 {((night_spend/total_spent)*100):.0f}% of your spending happens late at night. "
                f"Consider setting a spending curfew to avoid impulse purchases."
            )

        if not suggestions:
            suggestions.append("Great job! Your spending habits look balanced this month. Keep it up! 🎉")

        return Response({
            'hour_frequency': hour_freq,
            'day_frequency': day_freq,
            'day_names': day_names,
            'top_categories': top_categories,
            'suggestions': suggestions,
            'financial_goals': financial_goals,
            'total_spent': round(total_spent, 2),
            'total_income': round(total_income, 2),
            'transaction_count': len(transactions)
        })


class PredictionsView(APIView):
    """Returns 3-month projected balance data and smart insight cards."""
    permission_classes = [IsAuthenticated]

    def get(self, request):
        import calendar as cal
        from datetime import timedelta
        now = timezone.now()
        transactions = Transaction.objects.filter(user=request.user, date__year=now.year, date__month=now.month)
        profile = getattr(request.user, 'dna_profile', None)
        total_income = float(profile.income_fixed + profile.income_variable) if profile else 0.0
        total_spent = sum(float(t.amount) for t in transactions)
        financial_goals = profile.financial_goals if profile else 'your goals'

        _, last_day = cal.monthrange(now.year, now.month)
        days_passed = now.day
        burn_rate_daily = total_spent / days_passed if days_passed > 0 else 0

        # Project 3 months forward
        projected_months = []
        cumulative_balance = total_income - total_spent  # current remaining

        for i in range(3):
            future_month = now.month + i + 1
            future_year = now.year
            if future_month > 12:
                future_month -= 12
                future_year += 1
            month_name = cal.month_name[future_month]
            _, days_in_future = cal.monthrange(future_year, future_month)

            projected_spend = burn_rate_daily * days_in_future
            projected_savings = total_income - projected_spend
            cumulative_balance += projected_savings

            projected_months.append({
                'month': f"{month_name} {future_year}",
                'projected_income': round(total_income, 2),
                'projected_spend': round(projected_spend, 2),
                'projected_savings': round(projected_savings, 2),
                'cumulative_balance': round(cumulative_balance, 2)
            })

        # Smart Insights
        insights = []
        budgets = Budget.objects.filter(user=request.user)
        for b in budgets:
            cat_spent = sum(float(t.amount) for t in transactions if t.category == b.category_name)
            allocated = float(b.allocated_amount) if b.allocated_amount else 0
            if allocated > 0:
                pct = (cat_spent / allocated) * 100
                if pct >= 115:
                    insights.append({
                        'type': 'warning',
                        'icon': '🚨',
                        'text': f"Predictive Warning: Your {b.category_name} spending is {pct:.0f}% of budget. Expect overspend if unchecked."
                    })
                elif pct >= 90:
                    insights.append({
                        'type': 'caution',
                        'icon': '⚠️',
                        'text': f"Caution: {b.category_name} is at {pct:.0f}% — you're approaching the limit this month."
                    })

        # Forecast savings streak
        monthly_savings = total_income - (burn_rate_daily * last_day)
        if monthly_savings > 0:
            insights.append({
                'type': 'positive',
                'icon': '📈',
                'text': f"Forecast: Based on your current savings streak, you'll have a surplus of ${monthly_savings:.2f} by month-end."
            })
        else:
            insights.append({
                'type': 'warning',
                'icon': '📉',
                'text': f"Alert: At your current burn rate, you'll overspend by ${abs(monthly_savings):.2f} this month."
            })

        # Goal timeline
        if total_income > 0 and monthly_savings > 0:
            insights.append({
                'type': 'info',
                'icon': '🎯',
                'text': f"Goal Progress: Saving ${monthly_savings:.2f}/month puts you on track for '{financial_goals}'."
            })

        return Response({
            'projected_months': projected_months,
            'insights': insights,
            'current_balance': round(total_income - total_spent, 2),
            'burn_rate_daily': round(burn_rate_daily, 2),
            'financial_goals': financial_goals
        })





class ReceiptScanView(APIView):
    permission_classes = [IsAuthenticated]

    def post(self, request):
        import base64
        receipt_file = request.FILES.get('receipt')
        if not receipt_file:
            return Response({'error': 'No receipt file uploaded'}, status=400)

        image_bytes = receipt_file.read()
        image_b64 = base64.b64encode(image_bytes).decode('utf-8')
        mime_type = receipt_file.content_type or 'image/jpeg'

        import os, json
        import requests as http_requests

        system_instruction = (
            "You are a precise receipt parser. Extract the Total Amount (float), "
            "Merchant Name, and Category (Food, Travel, Shopping, Entertainment, "
            "Utilities, Healthcare, Education, Housing, Insurance, Others). "
            "Return ONLY a valid JSON object like: "
            "{\"total_amount\": 45.99, \"merchant_name\": \"Starbucks\", \"category\": \"Food\"}. "
            "Map 'Starbucks' to Food, 'Uber' to Travel, and 'Petrol' to Utilities."
        )

        parsed = None

        # --- Primary: OpenRouter (Vision Model) ---
        openrouter_key = os.environ.get('OPENROUTER_API_KEY', '')
        if openrouter_key and openrouter_key != 'your_key_here':
            try:
                resp = http_requests.post(
                    'https://openrouter.ai/api/v1/chat/completions',
                    headers={
                        'Authorization': f'Bearer {openrouter_key}',
                        'Content-Type': 'application/json',
                    },
                    json={
                        # Nemotron is a text-only model and will reject images.
                        # Using google/gemini-2.0-flash-lite-preview-02-05:free which is 100% free on OpenRouter and supports vision.
                        'model': 'google/gemini-2.0-flash-lite-preview-02-05:free',
                        'messages': [
                            {'role': 'system', 'content': system_instruction},
                            {'role': 'user', 'content': [
                                {'type': 'text', 'text': 'Parse this receipt image and return JSON.'},
                                {'type': 'image_url', 'image_url': {'url': f'data:{mime_type};base64,{image_b64}'}}
                            ]}
                        ],
                        'max_tokens': 300,
                    },
                    timeout=30
                )
                resp_data = resp.json()
                if 'error' in resp_data:
                    print(f"[OCR] OpenRouter API Error: {resp_data['error']}")
                else:
                    text_response = resp_data.get('choices', [{}])[0].get('message', {}).get('content', '')
                    clean_text = text_response.strip()
                    if clean_text.startswith('```'):
                        clean_text = clean_text.split('\n', 1)[1] if '\n' in clean_text else clean_text[3:]
                    if clean_text.endswith('```'):
                        clean_text = clean_text[:-3]
                    clean_text = clean_text.strip()
                    parsed = json.loads(clean_text)
            except Exception as e:
                print(f"[OCR] OpenRouter Exception: {str(e)}")
                parsed = None  # Fallback to Gemini

        # --- Fallback: Gemini API ---
        if not parsed:
            gemini_key = os.environ.get('GEMINI_API_KEY', '')
            if gemini_key and gemini_key != 'your_key_here':
                try:
                    api_url = f'https://generativelanguage.googleapis.com/v1beta/models/gemini-2.0-flash:generateContent?key={gemini_key}'
                    payload = {
                        'contents': [{
                            'parts': [
                                {'text': system_instruction + '\nParse this receipt:'},
                                {'inline_data': {'mime_type': mime_type, 'data': image_b64}}
                            ]
                        }]
                    }
                    resp = http_requests.post(api_url, json=payload, timeout=30)
                    resp_data = resp.json()
                    if 'error' in resp_data:
                        print(f"[OCR] Gemini API Error: {resp_data['error']}")
                    else:
                        text_response = resp_data.get('candidates', [{}])[0].get('content', {}).get('parts', [{}])[0].get('text', '')
                        clean_text = text_response.strip()
                        if clean_text.startswith('```'):
                            clean_text = clean_text.split('\n', 1)[1] if '\n' in clean_text else clean_text[3:]
                        if clean_text.endswith('```'):
                            clean_text = clean_text[:-3]
                        clean_text = clean_text.strip()
                        parsed = json.loads(clean_text)
                except Exception as e:
                    print(f"[OCR] Gemini Exception: {str(e)}")
                    parsed = None

        # --- Process result ---
        if not parsed:
            return Response({
                'status': 'success', 'needs_review': True,
                'raw_data': {'amount': 0, 'merchant': 'Unknown', 'category': 'Others'},
                'message': 'AI parsing failed. Please enter details manually.'
            })

        amount = float(parsed.get('total_amount', 0))
        merchant = parsed.get('merchant_name', 'Receipt Scan')
        category = parsed.get('category', 'Others')

        # Force merchant-category mappings
        m_lower = merchant.lower()
        MERCHANT_MAP = {
            'starbucks': 'Food', 'mcdonald': 'Food', 'subway': 'Food', 'dominos': 'Food',
            'uber': 'Travel', 'lyft': 'Travel', 'ola': 'Travel',
            'netflix': 'Entertainment', 'spotify': 'Entertainment',
            'petrol': 'Utilities', 'shell': 'Utilities', 'hp petrol': 'Utilities',
            'amazon': 'Shopping', 'flipkart': 'Shopping',
        }
        for key, cat in MERCHANT_MAP.items():
            if key in m_lower:
                category = cat
                break

        if amount <= 0 or merchant == 'Unknown':
            return Response({
                'status': 'success', 'needs_review': True,
                'raw_data': {'amount': amount, 'merchant': merchant, 'category': category},
                'message': 'AI could not fully read the receipt. Please review the details.'
            })

        now = timezone.now()
        is_night = now.hour >= 22 or now.hour <= 4

        transaction = Transaction.objects.create(
            user=request.user, amount=amount, category=category,
            sub_category=merchant, description=f'Receipt scan: {merchant}',
            is_night_spending=is_night
        )

        return Response({
            'status': 'success', 'needs_review': False,
            'transaction_id': transaction.id, 'amount': amount,
            'category': category, 'merchant': merchant,
            'message': f'Receipt scanned! Logged {amount:.2f} under {category} ({merchant}).'
        })


# ─── Password Recovery ────────────────────────────
class ForgotPasswordView(APIView):
    permission_classes = [AllowAny]

    def post(self, request):
        import random
        from django.core.mail import send_mail
        from .models import PasswordResetOTP

        email = request.data.get('email', '').strip()
        if not email:
            return Response({'error': 'Email is required.'}, status=400)

        try:
            user = User.objects.get(email=email)
        except User.DoesNotExist:
            return Response({'error': 'No account found with this email.'}, status=404)

        otp_code = str(random.randint(100000, 999999))

        # Invalidate old OTPs
        PasswordResetOTP.objects.filter(user=user, is_used=False).update(is_used=True)
        PasswordResetOTP.objects.create(user=user, otp_code=otp_code)

        try:
            send_mail(
                subject='WiseWallet — Password Reset OTP',
                message=f'Your OTP for password reset is: {otp_code}\n\nThis code is valid for 10 minutes.\n\nIf you did not request this, please ignore this email.',
                from_email=None,  # Uses DEFAULT_FROM_EMAIL
                recipient_list=[email],
                fail_silently=False,
            )
        except Exception:
            # Fallback: console output for testing
            import logging
            logging.getLogger(__name__).info(f"OTP for {email}: {otp_code}")

        return Response({'status': 'success', 'message': 'OTP sent to your email.'})


class VerifyOTPView(APIView):
    permission_classes = [AllowAny]

    def post(self, request):
        from .models import PasswordResetOTP
        import hashlib, time

        email = request.data.get('email', '').strip()
        otp = request.data.get('otp', '').strip()

        if not email or not otp:
            return Response({'error': 'Email and OTP are required.'}, status=400)

        try:
            user = User.objects.get(email=email)
        except User.DoesNotExist:
            return Response({'error': 'Invalid email.'}, status=404)

        otp_record = PasswordResetOTP.objects.filter(
            user=user, otp_code=otp, is_used=False
        ).order_by('-created_at').first()

        if not otp_record or not otp_record.is_valid():
            return Response({'error': 'Invalid or expired OTP.'}, status=400)

        # Mark OTP as used and generate temp token
        otp_record.is_used = True
        otp_record.save()

        temp_token = hashlib.sha256(f"{user.pk}-{time.time()}".encode()).hexdigest()[:32]
        request.session[f'reset_token_{temp_token}'] = user.pk

        return Response({'status': 'success', 'reset_token': temp_token})


class ResetPasswordView(APIView):
    permission_classes = [AllowAny]

    def post(self, request):
        token = request.data.get('reset_token', '')
        new_password = request.data.get('new_password', '')

        if not token or not new_password:
            return Response({'error': 'Token and new password are required.'}, status=400)

        user_pk = request.session.get(f'reset_token_{token}')
        if not user_pk:
            return Response({'error': 'Invalid or expired reset token.'}, status=400)

        try:
            user = User.objects.get(pk=user_pk)
        except User.DoesNotExist:
            return Response({'error': 'User not found.'}, status=404)

        user.set_password(new_password)
        user.save()

        # Clean up session
        del request.session[f'reset_token_{token}']

        return Response({'status': 'success', 'message': 'Password reset successfully! Please login.'})


# ─── Admin Dashboard Views ──────────────────────────

class AdminManualLoginView(APIView):
    permission_classes = [AllowAny]
    
    def post(self, request):
        username = request.data.get('username')
        password = request.data.get('password')
        
        # Hardcoded check as requested by user
        if username == 'admin' and password == 'WiseAdminPassword@2024':
            return Response({
                'status': 'success',
                'admin_token': 'BYPASS_ADMIN_TOKEN_2024', # Simple hardcoded token
                'message': 'Welcome Admin!'
            })
        return Response({'error': 'Invalid Admin Credentials'}, status=401)

class AdminDashboardStatsView(APIView):
    permission_classes = [AllowAny] # Restricted by logic inside

    def get(self, request):
        # Check for bypass token
        bypass_token = request.headers.get('Admin-Bypass-Token')
        if bypass_token != 'BYPASS_ADMIN_TOKEN_2024':
            return Response({'error': 'Unauthorized'}, status=403)
            
        now = timezone.now()
        today = now.date()
        
        total_users = User.objects.count()
        active_users_today = User.objects.filter(last_login__date=today).count()
        total_transactions = Transaction.objects.count()
        
        # Suspicious Activity logic
        # 1. Transactions > 50,000 INR
        high_value_txs = Transaction.objects.filter(amount__gt=50000).count()
        # 2. Users with more than 15 transactions in 24h
        yesterday = now - timedelta(hours=24)
        multi_tx_users = Transaction.objects.filter(date__gte=yesterday).values('user').annotate(cnt=Count('id')).filter(cnt__gt=15).count()
        # 3. Duplicate transactions (same user, amount, category within 10 mins)
        duplicates = 0
        all_recent = Transaction.objects.filter(date__gte=yesterday).order_by('user', 'date')
        for i in range(1, len(all_recent)):
            t1 = all_recent[i-1]
            t2 = all_recent[i]
            if t1.user == t2.user and t1.amount == t2.amount and t1.category == t2.category:
                if (t2.date - t1.date).total_seconds() < 600:
                    duplicates += 1
        
        suspicious_count = high_value_txs + multi_tx_users + duplicates
        
        # Drop-off stats
        # Registered but not onboarded (no personality tag)
        signup_dropoff = User.objects.filter(dna_profile__is_onboarded=False).count()
        # Onboarded but zero transactions
        onboarding_dropoff = User.objects.filter(dna_profile__is_onboarded=True).annotate(tx_count=Count('transactions')).filter(tx_count=0).count()
        
        # Most used categories
        category_stats = Transaction.objects.values('category').annotate(count=Count('id')).order_by('-count')[:5]
        
        # Highly active users (most transactions)
        highly_active_users = User.objects.annotate(tx_count=Count('transactions')).order_by('-tx_count')[:10]
        user_data = [{'username': u.username, 'tx_count': u.tx_count} for u in highly_active_users]
        
        return Response({
            'total_users': total_users,
            'active_users_today': active_users_today,
            'total_transactions': total_transactions,
            'suspicious_count': suspicious_count,
            'drop_off': {
                'signup_dropoff': signup_dropoff,
                'onboarding_dropoff': onboarding_dropoff
            },
            'most_used_categories': list(category_stats),
            'highly_active_users': user_data
        })

class AdminUserListView(APIView):
    permission_classes = [AllowAny]

    def get(self, request):
        bypass_token = request.headers.get('Admin-Bypass-Token')
        if bypass_token != 'BYPASS_ADMIN_TOKEN_2024':
            return Response({'error': 'Unauthorized'}, status=403)
            
        users = User.objects.all().order_by('-date_joined')
        data = []
        for u in users:
            data.append({
                'id': u.id,
                'username': u.username,
                'email': u.email,
                'date_joined': u.date_joined,
                'is_active': u.is_active,
                'is_superuser': u.is_superuser,
                'last_login': u.last_login
            })
        return Response(data)

class AdminUserActionView(APIView):
    permission_classes = [AllowAny]

    def post(self, request, user_id):
        bypass_token = request.headers.get('Admin-Bypass-Token')
        if bypass_token != 'BYPASS_ADMIN_TOKEN_2024':
            return Response({'error': 'Unauthorized'}, status=403)
            
        action = request.data.get('action')
        try:
            target_user = User.objects.get(id=user_id)
            if action == 'block':
                target_user.is_active = False
                target_user.save()
            elif action == 'unblock':
                target_user.is_active = True
                target_user.save()
            return Response({'status': 'success'})
        except User.DoesNotExist:
            return Response({'error': 'User not found'}, status=404)

    def delete(self, request, user_id):
        bypass_token = request.headers.get('Admin-Bypass-Token')
        if bypass_token != 'BYPASS_ADMIN_TOKEN_2024':
            return Response({'error': 'Unauthorized'}, status=403)
            
        try:
            target_user = User.objects.get(id=user_id)
            if target_user.is_superuser:
                return Response({'error': 'Cannot delete superuser'}, status=403)
            target_user.delete()
            return Response({'status': 'deleted'})
        except User.DoesNotExist:
            return Response({'error': 'User not found'}, status=404)

from .models import Feedback
from .serializers import FeedbackSerializer

class FeedbackView(APIView):
    permission_classes = [AllowAny] # Logic handles internal restriction

    def get(self, request):
        # Admin can see all, regular user sees only their own
        bypass_token = request.headers.get('Admin-Bypass-Token')
        if bypass_token == 'BYPASS_ADMIN_TOKEN_2024':
            feedbacks = Feedback.objects.all().order_by('-created_at')
        elif request.user.is_authenticated:
            feedbacks = Feedback.objects.filter(user=request.user).order_by('-created_at')
        else:
            return Response({'error': 'Login required to view feedback.'}, status=401)
        
        serializer = FeedbackSerializer(feedbacks, many=True)
        return Response(serializer.data)

    def post(self, request):
        if not request.user.is_authenticated:
            return Response({'error': 'Login required to submit feedback.'}, status=401)
        
        serializer = FeedbackSerializer(data=request.data)
        if serializer.is_valid():
            serializer.save(user=request.user)
            return Response({'status': 'success', 'message': 'Thank you! Your feedback has been saved and shared with the WiseWallet team.'})
        return Response(serializer.errors, status=400)

