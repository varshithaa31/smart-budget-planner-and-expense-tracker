import os
import random
import re

def determine_financial_personality(income, category, goals):
    """
    Mock AI logic for assigning a financial personality tag.
    Without an API key, it randomly assigns one of the three core tags.
    """
    api_key = os.environ.get('OPENAI_API_KEY')
    tags = ['Saver', 'Spender', 'Balanced']
    
    # If no real key is set, mock it
    if not api_key or api_key == 'your_key_here':
        # Simple heuristic based mocking
        if income > 5000 and 'save' in str(goals).lower():
            return 'Saver'
        return random.choice(tags)
    
    # Placeholder for real OpenAI call in the future
    return 'Balanced'

from .models import Budget

# The 9 standard categories + Others (always last)
BUDGET_CATEGORIES = [
    'Food', 'Travel', 'Utilities', 'Shopping', 'Education',
    'Entertainment', 'Recurrent Expenses', 'Savings', 'Others'
]

# Personality-based allocation percentages for each category
ALLOCATION_PROFILES = {
    'Saver': {
        'Food': 12, 'Travel': 5, 'Utilities': 10, 'Education': 8,
        'Shopping': 4, 'Entertainment': 3,
        'Recurrent Expenses': 13, 'Savings': 40, 'Others': 5
    },
    'Spender': {
        'Food': 18, 'Travel': 10, 'Utilities': 10, 'Education': 5,
        'Shopping': 12, 'Entertainment': 10,
        'Recurrent Expenses': 15, 'Savings': 10, 'Others': 10
    },
    'Balanced': {
        'Food': 15, 'Travel': 8, 'Utilities': 10, 'Education': 7,
        'Shopping': 8, 'Entertainment': 7,
        'Recurrent Expenses': 15, 'Savings': 22, 'Others': 8
    }
}

def auto_allocate_budget(user, income_fixed, income_variable, personality_tag):
    """
    Creates automated budget categories based on the DNA personality tag.
    Generates 9 standard categories with 'Others' always last.
    """
    total_income = float(income_fixed) + float(income_variable)
    profile = ALLOCATION_PROFILES.get(personality_tag, ALLOCATION_PROFILES['Balanced'])
    
    # Delete existing budgets for clean re-allocation
    Budget.objects.filter(user=user).delete()
    
    for category in BUDGET_CATEGORIES:
        percentage = profile.get(category, 0)
        amount = (total_income * percentage) / 100.0 if total_income > 0 else 0
        Budget.objects.create(
            user=user,
            category_name=category,
            allocated_percentage=percentage,
            allocated_amount=round(amount, 2)
        )


# Category keyword mapping for AI expense extraction
CATEGORY_KEYWORDS = {
    'Food': ['food', 'lunch', 'dinner', 'breakfast', 'coffee', 'starbucks', 'restaurant', 'pizza', 'burger', 'snack', 'grocery', 'meal', 'eat', 'drink', 'cafe'],
    'Travel': ['uber', 'lyft', 'gas', 'fuel', 'transit', 'bus', 'train', 'flight', 'taxi', 'travel', 'trip', 'commute', 'metro', 'petrol', 'diesel', 'parking'],
    'Utilities': ['electricity', 'water', 'internet', 'wifi', 'phone', 'bill', 'rent', 'utility', 'mobile', 'broadband', 'gas bill'],
    'Education': ['book', 'course', 'tuition', 'school', 'college', 'university', 'class', 'study', 'learning', 'udemy', 'coursera', 'education'],
    'Shopping': ['shopping', 'amazon', 'flipkart', 'clothes', 'shoes', 'gadget', 'electronics', 'walmart', 'target', 'buy', 'purchase', 'order'],
    'Entertainment': ['netflix', 'spotify', 'movie', 'game', 'concert', 'subscription', 'music', 'streaming', 'party', 'fun', 'hulu', 'disney'],
    'Recurrent Expenses': ['loan', 'emi', 'mortgage', 'installment', 'credit card', 'insurance', 'premium', 'dues', 'membership', 'recurring', 'monthly', 'annual fee'],
    'Savings': ['savings', 'invest', 'deposit', 'mutual fund', 'stock', 'sip', 'fd', 'fixed deposit'],
}

def extract_expense_info(user, text):
    """
    AI extraction: extracts amount and category from natural language.
    Maps to the 9 standard budget categories.
    """
    amount = 0.0
    match = re.search(r'[\$₹€]?\s*(\d+(?:[,]\d{3})*(?:\.\d+)?)', text)
    if match:
        amount = float(match.group(1).replace(',', ''))
        
    category = "Others"
    text_lower = text.lower()
    
    for cat, keywords in CATEGORY_KEYWORDS.items():
        if any(kw in text_lower for kw in keywords):
            category = cat
            break
    
    is_subscription = category == 'Entertainment' and any(k in text_lower for k in ['subscription', 'netflix', 'spotify', 'hulu', 'disney'])
    
    return {
        'amount': amount, 
        'category': category, 
        'sub_category': 'AI-Assigned',
        'is_subscription_leak': is_subscription
    }
