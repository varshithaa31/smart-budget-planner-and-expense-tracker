from django.db import models
from django.contrib.auth.models import AbstractUser

class CustomUser(AbstractUser):
    # SSO and other features to follow
    pass

class UserDNAProfile(models.Model):
    USER_CATEGORIES = (
        ('Student', 'Student'),
        ('Professional', 'Professional'),
        ('Retired', 'Retired'),
        ('Other', 'Other'),
    )
    PERSONALITY_TAGS = (
        ('Saver', 'Saver'),
        ('Spender', 'Spender'),
        ('Balanced', 'Balanced'),
    )
    user = models.OneToOneField(CustomUser, on_delete=models.CASCADE, related_name='dna_profile')
    income_fixed = models.DecimalField(max_digits=12, decimal_places=2, default=0.0)
    income_variable = models.DecimalField(max_digits=12, decimal_places=2, default=0.0)
    user_category = models.CharField(max_length=50, choices=USER_CATEGORIES, default='Other')
    personality_tag = models.CharField(max_length=50, choices=PERSONALITY_TAGS, null=True, blank=True)
    financial_goals = models.TextField(blank=True)
    is_onboarded = models.BooleanField(default=False)
    preferred_currency = models.CharField(max_length=5, default='USD')
    profile_photo = models.ImageField(upload_to='profile_photos/', null=True, blank=True)

    def __str__(self):

        return f"{self.user.username} - {self.personality_tag}"

class Goal(models.Model):
    user = models.ForeignKey(CustomUser, on_delete=models.CASCADE, related_name='goals')
    name = models.CharField(max_length=100)
    target_amount = models.DecimalField(max_digits=12, decimal_places=2)
    current_amount = models.DecimalField(max_digits=12, decimal_places=2, default=0.0)
    deadline = models.DateField(null=True, blank=True)

    def __str__(self):
        return f"{self.name} - {self.target_amount}"

class Budget(models.Model):
    user = models.ForeignKey(CustomUser, on_delete=models.CASCADE, related_name='budgets')
    category_name = models.CharField(max_length=100)
    allocated_percentage = models.DecimalField(max_digits=5, decimal_places=2) # e.g., 50.00 for 50%
    allocated_amount = models.DecimalField(max_digits=12, decimal_places=2, null=True, blank=True)

    def __str__(self):
        return f"{self.category_name} - {self.allocated_percentage}%"

from django.utils import timezone

class Transaction(models.Model):
    user = models.ForeignKey(CustomUser, on_delete=models.CASCADE, related_name='transactions')
    amount = models.DecimalField(max_digits=12, decimal_places=2)
    category = models.CharField(max_length=100)
    sub_category = models.CharField(max_length=100, null=True, blank=True)
    date = models.DateTimeField(default=timezone.now)
    description = models.TextField(blank=True)
    is_night_spending = models.BooleanField(default=False)
    is_subscription_leak = models.BooleanField(default=False)

    def __str__(self):
        return f"{self.amount} - {self.category}"

class Notification(models.Model):
    user = models.ForeignKey(CustomUser, on_delete=models.CASCADE, related_name='notifications')
    message = models.TextField()
    is_read = models.BooleanField(default=False)
    created_at = models.DateTimeField(auto_now_add=True)
    type = models.CharField(max_length=50) # e.g. "Badge", "Streak", "Alert"

    def __str__(self):
        return f"{self.type} - {self.user.username}"

class Feedback(models.Model):
    RATING_CHOICES = (
        (1, '☹️ Very Bad'),
        (2, '🙁 Bad'),
        (3, '😐 Neutral'),
        (4, '🙂 Good'),
        (5, '😍 Excellent'),
    )
    user = models.ForeignKey(CustomUser, on_delete=models.CASCADE, related_name='feedbacks')
    rating = models.IntegerField(choices=RATING_CHOICES)
    comment = models.TextField(blank=True)
    created_at = models.DateTimeField(auto_now_add=True)

    def __str__(self):
        return f"{self.user.username} - {self.get_rating_display()}"

class PasswordResetOTP(models.Model):
    user = models.ForeignKey(CustomUser, on_delete=models.CASCADE, related_name='password_otps')
    otp_code = models.CharField(max_length=6)
    created_at = models.DateTimeField(auto_now_add=True)
    is_used = models.BooleanField(default=False)

    def is_valid(self):
        from django.utils import timezone
        from datetime import timedelta
        return not self.is_used and (timezone.now() - self.created_at) < timedelta(minutes=10)

    def __str__(self):
        return f"OTP for {self.user.username} - {'Used' if self.is_used else 'Active'}"


