from django.apps import AppConfig
from django.db.models.signals import post_migrate

class ApiConfig(AppConfig):
    default_auto_field = 'django.db.models.BigAutoField'
    name = 'api'

    def ready(self):
        post_migrate.connect(create_only_admin, sender=self)

def create_only_admin(sender, **kwargs):
    from django.contrib.auth import get_user_model
    User = get_user_model()
    
    username = 'admin'
    email = 'admin@wisewallet.com'
    password = 'WiseAdminPassword@2024'

    # Clear other superusers to ensure "only one admin"
    other_superusers = User.objects.filter(is_superuser=True).exclude(username=username)
    if other_superusers.exists():
        other_superusers.delete()
    
    # Ensure the main admin exists and is set correctly
    if not User.objects.filter(username=username).exists():
        User.objects.create_superuser(username=username, email=email, password=password)
    else:
        # Update existing to be superuser if it somehow isn't
        user = User.objects.get(username=username)
        if not user.is_superuser:
            user.is_superuser = True
            user.is_staff = True
            user.save()
