from rest_framework import serializers
from django.contrib.auth import get_user_model

User = get_user_model()

class CustomUserSerializer(serializers.ModelSerializer):
    class Meta:
        model = User
        fields = ('id', 'username', 'email', 'password')
        extra_kwargs = {'password': {'write_only': True}}

    def create(self, validated_data):
        user = User.objects.create_user(
            username=validated_data['username'],
            email=validated_data.get('email', ''),
            password=validated_data['password']
        )
        return user

from .models import UserDNAProfile, Feedback

class UserDNAProfileSerializer(serializers.ModelSerializer):
    class Meta:
        model = UserDNAProfile
        fields = ('income_fixed', 'income_variable', 'user_category', 'personality_tag', 'financial_goals')
        read_only_fields = ('personality_tag',)

class UserProfileSerializer(serializers.ModelSerializer):
    username = serializers.CharField(source='user.username', read_only=True)
    email = serializers.EmailField(source='user.email', read_only=True)
    
    class Meta:
        model = UserDNAProfile
        fields = ('username', 'email', 'income_fixed', 'income_variable', 
                  'user_category', 'personality_tag', 'financial_goals',
                  'is_onboarded', 'preferred_currency')
        read_only_fields = ('personality_tag', 'is_onboarded')

class FeedbackSerializer(serializers.ModelSerializer):
    username = serializers.CharField(source='user.username', read_only=True)
    
    class Meta:
        model = Feedback
        fields = ('id', 'username', 'rating', 'comment', 'created_at')
        read_only_fields = ('created_at',)
