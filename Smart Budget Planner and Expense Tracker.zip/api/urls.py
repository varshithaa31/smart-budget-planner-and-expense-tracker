from django.urls import path
from rest_framework_simplejwt.views import (
    TokenObtainPairView,
    TokenRefreshView,
)
from .views import (
    RegisterView, OnboardingDNAView, DashboardDataView,
    QuickAddTransactionView, ManualAddTransactionView, TransactionCorrectionView,
    ChatbotView, BudgetListView, BudgetDetailView,
    TransactionHistoryView, LoginCheckView, UserProfileView,
    MonthlyReportView, DownloadReportPDFView,
    HabitsAnalyticsView, PredictionsView,
    FeedbackView, ReceiptScanView,
    ForgotPasswordView, VerifyOTPView, ResetPasswordView,
    AdminDashboardStatsView, AdminUserListView, AdminUserActionView,
    AdminManualLoginView, TransactionDetailView
)

urlpatterns = [
    path('admin/manual-login/', AdminManualLoginView.as_view(), name='admin_manual_login'),
    path('transactions/quick-add/', QuickAddTransactionView.as_view(), name='quick_add'),
    path('transactions/manual-add/', ManualAddTransactionView.as_view(), name='manual_add'),
    path('transactions/<int:transaction_id>/correct/', TransactionCorrectionView.as_view(), name='correct_transaction'),
    path('transactions/history/', TransactionHistoryView.as_view(), name='transaction_history'),
    path('transactions/<int:pk>/', TransactionDetailView.as_view(), name='transaction_detail'),
    path('transactions/scan-receipt/', ReceiptScanView.as_view(), name='scan_receipt'),

    path('dashboard/data/', DashboardDataView.as_view(), name='dashboard_data'),
    path('budgets/', BudgetListView.as_view(), name='budget_list'),
    path('budgets/<int:pk>/', BudgetDetailView.as_view(), name='budget_detail'),
    path('chat/', ChatbotView.as_view(), name='chatbot_api'),
    path('onboarding/dna/', OnboardingDNAView.as_view(), name='onboarding_dna'),
    path('auth/login/', TokenObtainPairView.as_view(), name='token_obtain_pair'),
    path('auth/login/refresh/', TokenRefreshView.as_view(), name='token_refresh'),
    path('auth/register/', RegisterView.as_view(), name='auth_register'),
    path('auth/check/', LoginCheckView.as_view(), name='auth_check'),
    path('auth/forgot-password/', ForgotPasswordView.as_view(), name='forgot_password'),
    path('auth/verify-otp/', VerifyOTPView.as_view(), name='verify_otp'),
    path('auth/reset-password/', ResetPasswordView.as_view(), name='reset_password'),
    path('profile/', UserProfileView.as_view(), name='user_profile'),
    path('reports/monthly/', MonthlyReportView.as_view(), name='monthly_report'),
    path('reports/download-pdf/', DownloadReportPDFView.as_view(), name='download_report_pdf'),
    path('analytics/habits/', HabitsAnalyticsView.as_view(), name='habits_analytics'),
    path('analytics/predictions/', PredictionsView.as_view(), name='predictions'),
    path('feedback/', FeedbackView.as_view(), name='feedback'),
    # Admin API
    path('admin/stats/', AdminDashboardStatsView.as_view(), name='admin_stats'),
    path('admin/users/', AdminUserListView.as_view(), name='admin_user_list'),
    path('admin/users/<int:user_id>/action/', AdminUserActionView.as_view(), name='admin_user_action'),
]
