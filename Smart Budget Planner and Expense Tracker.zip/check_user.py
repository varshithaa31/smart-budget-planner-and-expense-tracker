import os
import django

os.environ.setdefault('DJANGO_SETTINGS_MODULE', 'smartbudget.settings')
django.setup()

from api.models import CustomUser

username = 'sugu'
user = CustomUser.objects.filter(username=username).first()

if user:
    print(f"USER_FOUND: {username}")
    print(f"IS_ACTIVE: {user.is_active}")
    print(f"IS_STAFF: {user.is_staff}")
    print(f"IS_SUPERUSER: {user.is_superuser}")
    print(f"EMAIL: {user.email}")
else:
    print(f"USER_NOT_FOUND: {username}")
    # List first 5 users for context
    print("EXISTING_USERS:")
    for u in CustomUser.objects.all()[:5]:
        print(f"- {u.username}")
