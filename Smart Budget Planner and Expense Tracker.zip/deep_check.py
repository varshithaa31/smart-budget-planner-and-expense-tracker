import os
import django

os.environ.setdefault('DJANGO_SETTINGS_MODULE', 'smartbudget.settings')
django.setup()

from api.models import CustomUser
from django.db import connection

print("--- Checking api_customuser table ---")
with connection.cursor() as cursor:
    cursor.execute("SELECT name FROM sqlite_master WHERE type='table';")
    tables = cursor.fetchall()
    print(f"Tables found: {[t[0] for t in tables]}")

    cursor.execute("SELECT username, email FROM api_customuser WHERE username LIKE '%sugu%' OR email LIKE '%sugu%';")
    matches = cursor.fetchall()
    print(f"Partial matches for 'sugu': {matches}")

    cursor.execute("SELECT COUNT(*) FROM api_customuser;")
    count = cursor.fetchone()[0]
    print(f"Total users in api_customuser: {count}")
