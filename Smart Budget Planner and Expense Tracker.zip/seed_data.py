import os, sys, django
os.environ.setdefault('DJANGO_SETTINGS_MODULE', 'smartbudget.settings')
django.setup()

from api.models import CustomUser, UserDNAProfile, Transaction, Budget, Feedback
from django.utils import timezone
from datetime import timedelta
import random

def seed():
    print("🚀 Starting Seed Process...")
    now = timezone.now()

    # 1. Ensure Admin exists
    admin_username = 'admin'
    admin, created = CustomUser.objects.get_or_create(username=admin_username, defaults={'email': 'admin@wisewallet.com', 'is_staff': True, 'is_superuser': True})
    if created:
        admin.set_password('WiseAdminPassword@2024')
        admin.save()
    print(f"✅ Admin: {admin_username}")

    # 2. Create Highly Active User (many transactions)
    active_user, _ = CustomUser.objects.get_or_create(username='power_user', defaults={'email': 'power@example.com'})
    active_user.set_password('test1234')
    active_user.save()
    UserDNAProfile.objects.get_or_create(user=active_user, defaults={'is_onboarded': True, 'personality_tag': 'Spender', 'income_fixed': 100000})
    
    # Create 30 transactions for power_user
    for i in range(30):
        Transaction.objects.create(
            user=active_user,
            amount=random.randint(50, 2000),
            category=random.choice(['Food', 'Shopping', 'Travel', 'Entertainment']),
            description=f"Transaction {i}",
            date=now - timedelta(days=random.randint(0, 5), hours=random.randint(0, 23))
        )
    print("✅ Created Power User with 30 transactions")

    # 3. Create Suspicious Activity
    # A. High Value Transaction
    suspicious_user, _ = CustomUser.objects.get_or_create(username='whale', defaults={'email': 'whale@example.com'})
    Transaction.objects.create(
        user=suspicious_user,
        amount=75000, # Above 50,000 threshold
        category='Others',
        description='Large suspicious transfer',
        date=now - timedelta(hours=2)
    )
    # B. Duplicate transactions (same amount, category, user within 10 mins)
    dup_time = now - timedelta(hours=1)
    for _ in range(3):
        Transaction.objects.create(
            user=suspicious_user,
            amount=500,
            category='Shopping',
            description='Duplicate payment test',
            date=dup_time + timedelta(minutes=random.randint(0, 5))
        )
    print("✅ Created Suspicious Activity (High Value & Duplicates)")

    # 4. Create Drop-off Users
    # A. Signup Drop-off (Registered but not onboarded)
    for i in range(5):
        u, _ = CustomUser.objects.get_or_create(username=f'dropoff_signup_{i}', defaults={'email': f's{i}@example.com'})
        UserDNAProfile.objects.get_or_create(user=u, defaults={'is_onboarded': False})
    
    # B. Onboarding Drop-off (Onboarded but 0 transactions)
    for i in range(3):
        u, _ = CustomUser.objects.get_or_create(username=f'dropoff_onboard_{i}', defaults={'email': f'o{i}@example.com'})
        UserDNAProfile.objects.get_or_create(user=u, defaults={'is_onboarded': True})
    print("✅ Created Drop-off Data (Signup and Onboarding drop-offs)")

    # 5. Create some general users and categories
    categories = ['Food', 'Travel', 'Shopping', 'Entertainment', 'Utilities', 'Healthcare', 'Education', 'Housing', 'Insurance', 'Others']
    for i in range(10):
        u, _ = CustomUser.objects.get_or_create(username=f'user_{i}', defaults={'email': f'user{i}@example.com'})
        u.last_login = now - timedelta(hours=random.randint(0, 12))
        u.save()
        UserDNAProfile.objects.get_or_create(user=u, defaults={'is_onboarded': True, 'income_fixed': random.randint(30000, 150000)})
        
        # Add a few transactions
        for _ in range(random.randint(1, 5)):
            Transaction.objects.create(
                user=u,
                amount=random.randint(100, 5000),
                category=random.choice(categories),
                description='Regular expense',
                date=now - timedelta(days=random.randint(0, 30))
            )
    
    print("✅ Created 10 General Users with transactions")
    print("\n🎉 Seed Data Injection Complete!")
    print(f"Total Users: {CustomUser.objects.count()}")
    print(f"Total Transactions: {Transaction.objects.count()}")

if __name__ == '__main__':
    seed()
