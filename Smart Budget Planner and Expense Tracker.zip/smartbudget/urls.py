"""
URL configuration for smartbudget project.
"""
from django.contrib import admin
from django.urls import path, include
from django.views.generic import TemplateView

urlpatterns = [
    path('admin/', admin.site.urls),
    path('api/', include('api.urls')),
    # path('accounts/', include('allauth.urls')),
    path('login/', TemplateView.as_view(template_name='login.html'), name='login'),
    path('register/', TemplateView.as_view(template_name='register.html'), name='register'),
    path('forgot-password/', TemplateView.as_view(template_name='forgot_password.html'), name='forgot_password_page'),
    path('onboarding/', TemplateView.as_view(template_name='onboarding.html'), name='onboarding'),
    path('dashboard/', TemplateView.as_view(template_name='dashboard.html'), name='dashboard'),
    path('profile/', TemplateView.as_view(template_name='dashboard.html'), name='profile'),
    path('habits/', TemplateView.as_view(template_name='dashboard.html'), name='habits'),
    path('predictions/', TemplateView.as_view(template_name='dashboard.html'), name='predictions'),
    path('admin-dashboard/', TemplateView.as_view(template_name='admin_dashboard.html'), name='admin_dashboard_page'),
    path('', TemplateView.as_view(template_name='index.html'), name='home'),
    # Reload trigger comment
]


